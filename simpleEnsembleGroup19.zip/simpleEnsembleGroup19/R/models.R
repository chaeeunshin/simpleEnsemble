#' Linear Regression
#' This function fit linear model.
#' @param X A matrix of predictor variables
#' @param y A vector of response variable
#' @return fitted linear model
#' @export
fitLinearModel <- function(X,y){
  result <- check_data(X,y)
  if(result$response_type =="binary"){
    stop("Response variable type should be continuous for Linear Regression")
  }else{
    model <- lm(result$y~X)
  }
  return(model)
}

#' Logistic Regression
#' This function fit logistic model.
#' @param X A matrix of predictor variables
#' @param y A vector of response variable
#' @return Fitted logistic model
#' @export
fitLogisticModel <- function(X,y){
  result <- check_data(X,y)
  if(result$response_type =="continuous"){
    stop("Response variable type should be binary for Logistic Regression")
  }else{
    model <- glm(result$y~X, family = "binomial")
  }
  return(model)
}

#' Ridge Regression
#' This function fit ridge model.
#' @param X A matrix of predictor variables
#' @param y A vector of response variable
#' @return Fitted ridge model
#' @import glmnet
#' @export
fitRidgeModel <- function(X,y){
  result <- check_data(X,y)
  cv <- glmnet::cv.glmnet(X, result$y , alpha = 0)
  model <- glmnet::glmnet(X, result$y, alpha = 0, lambda = cv$lambda.min)
  return(model)
}

#' Lasso Regression
#' This function fit lasso model.
#' @param X A matrix of predictor variables
#' @param y A vector of response variable
#' @return Fitted lasso model 
#' @import glmnet
#' @export
fitLassoModel <- function(X,y){
  require("glmnet")
  result <- check_data(X,y)
  cv <- glmnet::cv.glmnet(X, result$y, alpha = 1)
  model <- glmnet::glmnet(X, result$y, alpha = 1, lambda = cv$lambda.min)
  return(model)
}

#' Elastic Net Regression
#' This function fit elastic net model.
#' @param X A matrix of predictor variables
#' @param y A vector of response variable
#' @return Fitted elastic net model
#' @import glmnet
#' @export
fitElasticNetModel <- function(X,y){
  require("glmnet")
  result <- check_data(X,y)
  cv <- glmnet::cv.glmnet(X, result$y, alpha = 0.5)
  model <- glmnet::glmnet(X, result$y, alpha = 0.5, lambda = cv$lambda.min)
  return(model)
}

#' Random Forest
#' This function fit random forest model.
#' @param X A matrix of predictor variables
#' @param y A vector of response variable
#' @return Fitted random forest model
#' @import randomForest
#' @export
fitRandomForestModel <- function(X, y, ntree = 500) {
  require("randomForest")
  result <- check_data(X,y)
  model <- randomForest::randomForest(X,y, ntree = ntree)
  return(model)
}


